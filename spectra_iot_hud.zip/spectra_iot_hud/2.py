from collections import deque
import json
import os
import statistics
import sys
import time
import serial
from PyQt6.QtCore import QPoint, QRectF, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QAction, QColor, QFont, QIcon, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QSystemTrayIcon,
    QVBoxLayout,
    QWidget,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SERIAL_PORT = "COM5"
BAUD_RATE = 115200
VAULT_FILE = os.path.join(BASE_DIR, "stark_rf_vault.json")
ALERT_COOLDOWN_SEC = 3.0


def load_vault() -> dict:
    if os.path.exists(VAULT_FILE):
        try:
            with open(VAULT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_vault(vault: dict) -> None:
    with open(VAULT_FILE, "w", encoding="utf-8") as f:
        json.dump(vault, f, indent=2)


def decode_frame(pulses: list[int]) -> dict:
    mid_cut = (min(pulses) + max(pulses)) / 2.0
    symbols = "".join("L" if p >= mid_cut else "S" for p in pulses)
    short_vals = [p for p in pulses if p < mid_cut]
    long_vals = [p for p in pulses if p >= mid_cut]
    short_avg = round(statistics.mean(short_vals), 1) if short_vals else 0.0
    long_avg = round(statistics.mean(long_vals), 1) if long_vals else 0.0
    ratio = round(long_avg / short_avg, 2) if short_avg > 0 else 0.0

    bits = []
    for i in range(0, len(symbols) - 1, 2):
        pair = symbols[i : i + 2]
        if pair == "SL":
            bits.append("0")
        elif pair == "LS":
            bits.append("1")
        else:
            bits.append("?")
    bit_str = "".join(bits)[:32]
    clean_ratio = round(1.0 - (bit_str.count("?") / max(len(bit_str), 1)), 2)
    return {
        "count": len(pulses),
        "short_us": short_avg,
        "long_us": long_avg,
        "ratio": ratio,
        "bits": bit_str,
        "clean_ratio": clean_ratio,
    }


def build_local_brief(level_tag: str, metrics: str, frame: dict | None, edges: int, duty: float, thresh: float) -> str:
    if "LEVEL-4" in level_tag:
        return f"Verified 433.92 MHz code locked at {duty:.1f}% duty ({edges} edges). Repeat presses to confirm fixed or rolling ID."
    if "LEVEL-3" in level_tag and frame is not None:
        return (
            f"Clean pulse train ({int(frame['clean_ratio'] * 100)}% bit clarity, ratio {frame['ratio']}x, "
            f"short {frame['short_us']} us / long {frame['long_us']} us). Compare bits across presses."
        )
    return f"Unstructured activity at {edges} edges (threshold {thresh:.1f}) and {duty:.1f}% duty; check for EMI, charger noise, or antenna proximity."


def make_arc_icon() -> QIcon:
    pix = QPixmap(32, 32)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor(0, 235, 255), 3))
    p.drawEllipse(4, 4, 24, 24)
    p.setPen(QPen(QColor(255, 185, 30), 2))
    p.drawEllipse(10, 10, 12, 12)
    p.end()
    return QIcon(pix)


class SerialScannerWorker(QThread):
    telem_updated = pyqtSignal(int, float, float, float, int)
    alert_triggered = pyqtSignal(str, str, str, str)
    status_changed = pyqtSignal(str)

    def __init__(self) -> None:
        super().__init__()
        self._running = True

    def stop(self) -> None:
        self._running = False

    def run(self) -> None:
        vault = load_vault()
        edge_hist: deque[int] = deque(maxlen=40)
        last_frame: dict | None = None
        last_alert = 0.0

        while self._running:
            try:
                with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1) as ser:
                    self.status_changed.emit(f"LINKED // {SERIAL_PORT} @ {BAUD_RATE}")
                    time.sleep(2)
                    while self._running:
                        line = ser.readline().decode("utf-8", errors="ignore").strip()
                        if not line:
                            continue

                        if line.startswith("FRAME:"):
                            try:
                                pulses = [int(x) for x in line[6:].split(",") if x]
                                if len(pulses) >= 24:
                                    last_frame = decode_frame(pulses)
                            except ValueError:
                                pass
                            continue

                        if line.startswith("TELEM:"):
                            try:
                                parts = dict(item.split("=") for item in line[6:].split(","))
                                edges = int(parts["EDGES"])
                                duty = float(parts["DUTY"])
                                pkt = int(parts["PKT"])
                            except ValueError:
                                continue

                            base_e = statistics.mean(edge_hist) if len(edge_hist) >= 5 else float(edges)
                            sd_e = max(statistics.pstdev(edge_hist), 4.0) if len(edge_hist) >= 5 else 4.0
                            thresh = round(max(base_e + 3.0 * sd_e, 25.0), 1)
                            edge_hist.append(edges)

                            self.telem_updated.emit(edges, duty, round(base_e, 1), thresh, len(vault))

                            now = time.time()
                            has_structured = last_frame is not None and last_frame["clean_ratio"] >= 0.70

                            if (pkt != 0 or has_structured or edges >= thresh) and (now - last_alert) >= ALERT_COOLDOWN_SEC:
                                last_alert = now
                                if pkt != 0:
                                    sig_key = f"PKT_{pkt}"
                                    codename = vault.setdefault(sig_key, f"BEACON-{len(vault) + 1:02d}")
                                    save_vault(vault)
                                    level_tag = "LEVEL-4 // LOCKED BEACON"
                                    metrics = f"PKT={pkt} | EDGES={edges} | DUTY={duty:.1f}%"
                                elif has_structured and last_frame is not None:
                                    sig_key = f"BITS_{last_frame['bits'][:16]}"
                                    codename = vault.setdefault(sig_key, f"SIG-{len(vault) + 1:02d}")
                                    save_vault(vault)
                                    level_tag = "LEVEL-3 // PULSE SIGNATURE"
                                    metrics = f"Pulses={last_frame['count']} | Ratio={last_frame['ratio']}x | Bits={last_frame['bits'][:20]}"
                                else:
                                    codename = "EMI / FIELD SPIKE"
                                    level_tag = "LEVEL-2 // RF ANOMALY"
                                    metrics = f"EDGES={edges} (Thresh={thresh}) | DUTY={duty:.1f}%"

                                brief = build_local_brief(level_tag, metrics, last_frame, edges, duty, thresh)
                                self.alert_triggered.emit(level_tag, codename, metrics, brief)
                                last_frame = None
            except Exception:
                self.status_changed.emit(f"STANDBY // AWAITING {SERIAL_PORT}...")
                time.sleep(2.5)


class ArcGaugeWidget(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setFixedSize(124, 124)
        self.edges = 0
        self.duty = 0.0
        self.thresh = 25.0
        self.alert_active = False

    def update_values(self, edges: int, duty: float, thresh: float, alert_active: bool) -> None:
        self.edges = edges
        self.duty = duty
        self.thresh = thresh
        self.alert_active = alert_active
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        outer_rect = QRectF(10, 10, 104, 104)
        inner_rect = QRectF(23, 23, 78, 78)

        painter.setPen(QPen(QColor(0, 210, 255, 45), 6))
        painter.drawArc(outer_rect, 0, 360 * 16)
        painter.setPen(QPen(QColor(255, 175, 0, 45), 5))
        painter.drawArc(inner_rect, 0, 360 * 16)

        edge_frac = min(self.edges / max(self.thresh * 1.5, 150.0), 1.0)
        edge_color = QColor(255, 75, 75, 235) if self.alert_active else QColor(0, 235, 255, 235)
        painter.setPen(QPen(edge_color, 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(outer_rect, 90 * 16, int(-edge_frac * 360 * 16))

        duty_frac = min(max(self.duty / 100.0, 0.0), 1.0)
        painter.setPen(QPen(QColor(255, 185, 30, 230), 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(inner_rect, 90 * 16, int(-duty_frac * 360 * 16))

        painter.setPen(QColor(225, 250, 255))
        painter.setFont(QFont("Consolas", 14, QFont.Weight.Bold))
        painter.drawText(outer_rect.adjusted(0, -10, 0, -10), Qt.AlignmentFlag.AlignCenter, f"{self.edges}")

        painter.setPen(QColor(0, 220, 255, 200))
        painter.setFont(QFont("Consolas", 8))
        painter.drawText(outer_rect.adjusted(0, 14, 0, 14), Qt.AlignmentFlag.AlignCenter, "EDGES")


class StarkSystemHUD(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._drag_pos: QPoint | None = None
        self._last_alert_ts = 0.0
        self._click_through = False
        self._init_ui()
        self._init_tray()

        self.worker = SerialScannerWorker()
        self.worker.telem_updated.connect(self.on_telem)
        self.worker.alert_triggered.connect(self.on_alert)
        self.worker.status_changed.connect(self.on_status)
        self.worker.start()

    def _init_ui(self) -> None:
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(410, 310)

        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.width() - self.width() - 24, 24)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        self.panel = QFrame()
        self.panel.setObjectName("HudPanel")
        self.panel.setStyleSheet(
            """
            QFrame#HudPanel {
                background-color: rgba(8, 18, 28, 195);
                border: 1.5px solid rgba(0, 225, 255, 175);
                border-radius: 12px;
            }
            QLabel {
                color: #D9F7FF;
                font-family: 'Consolas', 'Cascadia Code', monospace;
            }
            QPushButton {
                background-color: rgba(0, 180, 220, 45);
                color: #7CEEFF;
                border: 1px solid rgba(0, 225, 255, 130);
                border-radius: 5px;
                font-family: 'Consolas', monospace;
                font-size: 10px;
                font-weight: bold;
                padding: 2px 7px;
            }
            QPushButton:hover {
                background-color: rgba(0, 225, 255, 120);
                color: #FFFFFF;
            }
            """
        )
        root.addWidget(self.panel)

        layout = QVBoxLayout(self.panel)
        layout.setContentsMargins(14, 10, 14, 12)
        layout.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("STARK // WIN11 SYSTEM HUD")
        title.setStyleSheet("color: #00E5FF; font-weight: bold; font-size: 12px; letter-spacing: 1px;")

        hide_btn = QPushButton("TRAY")
        hide_btn.clicked.connect(self.hide)
        quit_btn = QPushButton("X")
        quit_btn.setFixedWidth(24)
        quit_btn.clicked.connect(self.shutdown_app)

        header.addWidget(title)
        header.addStretch()
        header.addWidget(hide_btn)
        header.addWidget(quit_btn)
        layout.addLayout(header)

        self.status_lbl = QLabel(f"STANDBY // AWAITING {SERIAL_PORT}...")
        self.status_lbl.setStyleSheet("color: #7CC8D8; font-size: 10px;")
        layout.addWidget(self.status_lbl)

        mid_row = QHBoxLayout()
        self.gauge = ArcGaugeWidget()
        mid_row.addWidget(self.gauge)

        stats_col = QVBoxLayout()
        stats_col.setSpacing(4)
        self.duty_lbl = QLabel("DUTY CYCLE : 00.0 %")
        self.duty_lbl.setStyleSheet("color: #FFB82E; font-size: 12px; font-weight: bold;")
        self.base_lbl = QLabel("ROOM BASE  : 00.0 EDGES")
        self.base_lbl.setStyleSheet("font-size: 11px;")
        self.thresh_lbl = QLabel("LOCK THRESH: 25.0 EDGES")
        self.thresh_lbl.setStyleSheet("font-size: 11px;")
        self.vault_lbl = QLabel(f"VAULT SIGS : {len(load_vault())} LOCKED")
        self.vault_lbl.setStyleSheet("color: #55FFB8; font-size: 11px; font-weight: bold;")

        stats_col.addWidget(self.duty_lbl)
        stats_col.addWidget(self.base_lbl)
        stats_col.addWidget(self.thresh_lbl)
        stats_col.addWidget(self.vault_lbl)
        mid_row.addLayout(stats_col)
        layout.addLayout(mid_row)

        self.lock_box = QFrame()
        self.lock_box.setStyleSheet(
            """
            QFrame {
                background-color: rgba(0, 35, 52, 165);
                border: 1px solid rgba(0, 225, 255, 100);
                border-radius: 8px;
            }
            """
        )
        lock_layout = QVBoxLayout(self.lock_box)
        lock_layout.setContentsMargins(10, 8, 10, 8)
        lock_layout.setSpacing(3)

        self.beacon_title = QLabel("STATUS // LOCAL SYSTEM OVERLAY ACTIVE")
        self.beacon_title.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: bold;")
        self.beacon_metrics = QLabel("Awaiting structured pulse frame or PKT ID...")
        self.beacon_metrics.setStyleSheet("color: #9ED8E6; font-size: 10px;")
        self.beacon_brief = QLabel("Offline mode active. Right-click tray icon for click-through or hide.")
        self.beacon_brief.setWordWrap(True)
        self.beacon_brief.setStyleSheet("color: #E5FAFF; font-size: 10px;")

        lock_layout.addWidget(self.beacon_title)
        lock_layout.addWidget(self.beacon_metrics)
        lock_layout.addWidget(self.beacon_brief)
        layout.addWidget(self.lock_box)

    def _init_tray(self) -> None:
        self.tray = QSystemTrayIcon(make_arc_icon(), self)
        self.tray.setToolTip("Stark Tactical RF HUD (COM5)")

        menu = QMenu()
        show_act = QAction("Show / Focus HUD", self)
        show_act.triggered.connect(self.show_hud)

        self.ghost_act = QAction("Click-Through Ghost Mode: OFF", self)
        self.ghost_act.triggered.connect(self.toggle_click_through)

        exit_act = QAction("Shutdown HUD", self)
        exit_act.triggered.connect(self.shutdown_app)

        menu.addAction(show_act)
        menu.addAction(self.ghost_act)
        menu.addSeparator()
        menu.addAction(exit_act)

        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_click)
        self.tray.show()

    def _on_tray_click(self, reason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            if self.isVisible():
                self.hide()
            else:
                self.show_hud()

    def show_hud(self) -> None:
        self.show()
        self.raise_()

    def toggle_click_through(self) -> None:
        self._click_through = not self._click_through
        self.setWindowFlag(Qt.WindowType.WindowTransparentForInput, self._click_through)
        self.ghost_act.setText(f"Click-Through Ghost Mode: {'ON' if self._click_through else 'OFF'}")
        self.show()

    def on_status(self, text: str) -> None:
        self.status_lbl.setText(text)

    def on_telem(self, edges: int, duty: float, base: float, thresh: float, vault_count: int) -> None:
        alert_active = (time.time() - self._last_alert_ts) < 2.5
        self.gauge.update_values(edges, duty, thresh, alert_active)
        self.duty_lbl.setText(f"DUTY CYCLE : {duty:04.1f} %")
        self.base_lbl.setText(f"ROOM BASE  : {base:04.1f} EDGES")
        self.thresh_lbl.setText(f"LOCK THRESH: {thresh:04.1f} EDGES")
        self.vault_lbl.setText(f"VAULT SIGS : {vault_count} LOCKED")

    def on_alert(self, level_tag: str, codename: str, metrics: str, brief: str) -> None:
        self._last_alert_ts = time.time()
        ts = time.strftime("%H:%M:%S")
        is_beacon = "LEVEL-4" in level_tag or "LEVEL-3" in level_tag
        accent = "#55FFB8" if is_beacon else "#FF6B6B"

        if not self.isVisible():
            self.show_hud()

        self.beacon_title.setStyleSheet(f"color: {accent}; font-size: 11px; font-weight: bold;")
        self.beacon_title.setText(f"[{ts}] {level_tag} -> {codename}")
        self.beacon_metrics.setText(metrics)
        self.beacon_brief.setText(brief)

    def mousePressEvent(self, event) -> None:
        if not self._click_through and event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event) -> None:
        if not self._click_through and self._drag_pos is not None and event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, event) -> None:
        self._drag_pos = None

    def shutdown_app(self) -> None:
        self.worker.stop()
        self.worker.wait(1500)
        self.tray.hide()
        QApplication.quit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    hud = StarkSystemHUD()
    hud.show()
    sys.exit(app.exec())