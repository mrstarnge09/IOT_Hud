#include <RCSwitch.h>

const int RF_DATA_PIN = 2; // D2 (Interrupt 0)
const unsigned long WINDOW_MS = 250;
const unsigned int MIN_PULSE_US = 100;
const unsigned int MAX_PULSE_US = 4500;
const unsigned int GAP_RESET_US = 5000;
const byte MAX_PULSES = 128;

RCSwitch mySwitch = RCSwitch();

volatile unsigned long edgeCount = 0;
volatile unsigned long totalHighUs = 0;
volatile unsigned long lastEdgeUs = 0;

volatile unsigned int rawBuf[MAX_PULSES];
volatile byte rawCount = 0;
volatile bool frameReady = false;

unsigned long lastWindowMs = 0;
unsigned long lastPktVal = 0;

void onScannerEdge() {
  unsigned long now = micros();
  unsigned long dt = now - lastEdgeUs;
  lastEdgeUs = now;

  if (dt >= MIN_PULSE_US && dt < 65000) {
    edgeCount++;
    if (digitalRead(RF_DATA_PIN) == LOW) {
      totalHighUs += dt;
    }
  }

  if (frameReady) return;

  if (dt >= GAP_RESET_US) {
    if (rawCount >= 24) {
      frameReady = true;
    } else {
      rawCount = 0;
    }
    return;
  }

  if (dt >= MIN_PULSE_US && dt <= MAX_PULSE_US && rawCount < MAX_PULSES) {
    rawBuf[rawCount++] = (unsigned int)dt;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(RF_DATA_PIN, INPUT);
  lastEdgeUs = micros();
  mySwitch.enableReceive(0);
  attachInterrupt(digitalPinToInterrupt(RF_DATA_PIN), onScannerEdge, CHANGE);
  Serial.println("SYS:STARK_RF_SCANNER_ONLINE");
}

void loop() {
  if (mySwitch.available()) {
    unsigned long val = mySwitch.getReceivedValue();
    if (val != 0) {
      lastPktVal = val;
    }
    mySwitch.resetAvailable();
  }

  if (frameReady) {
    noInterrupts();
    byte count = rawCount;
    unsigned int copyBuf[MAX_PULSES];
    for (byte i = 0; i < count; i++) {
      copyBuf[i] = rawBuf[i];
    }
    rawCount = 0;
    frameReady = false;
    interrupts();

    Serial.print("FRAME:");
    for (byte i = 0; i < count; i++) {
      Serial.print(copyBuf[i]);
      if (i < count - 1) Serial.print(",");
    }
    Serial.println();
  }

  unsigned long nowMs = millis();
  if (nowMs - lastWindowMs >= WINDOW_MS) {
    noInterrupts();
    unsigned long edges = edgeCount;
    unsigned long highUs = totalHighUs;
    edgeCount = 0;
    totalHighUs = 0;
    interrupts();

    float dutyPct = (highUs / (WINDOW_MS * 1000.0)) * 100.0;

    Serial.print("TELEM:EDGES=");
    Serial.print(edges);
    Serial.print(",DUTY=");
    Serial.print(dutyPct, 2);
    Serial.print(",PKT=");
    Serial.println(lastPktVal);

    lastPktVal = 0;
    lastWindowMs = nowMs;
  }
}
