from collections import deque
import json
import os
import statistics
import sys
import time
import serial
from google import genai
from google.genai import types
from PyQt6.QtCore import QPoint, QRectF, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPen
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

SERIAL_PORT = "COM5"
BAUD_RATE = 115200
VAULT_FILE = "stark_rf_vault.json"
ALERT_COOLDOWN_SEC = 3.0
MODELS_TO_TRY = ["gemini-3.8-flash", "gemini-2.5-flash"]

API_KEY = "Api key " or os.environ.get("GEMINI_API_KEY", "")
client = genai.Client(api_key=API_KEY)


def load_vault() -> dict:
    if os.path.exists(VAULT_FILE):
        try:
            with open(VAULT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_vault(vault: dict) -> None:
    with open(VAULT_FILE, "w", encoding="utf-8") as f:
        json.dump(vault, f, indent=2)


def decode_frame(pulses: list[int]) -> dict:
    mid_cut = (min(pulses) + max(pulses)) / 2.0
    symbols = "".join("L" if p >= mid_cut else "S" for p in pulses)
    short_vals = [p for p in pulses if p < mid_cut]
    long_vals = [p for p in pulses if p >= mid_cut]
    short_avg = round(statistics.mean(short_vals), 1) if short_vals else 0.0
    long_avg = round(statistics.mean(long_vals), 1) if long_vals else 0.0
    ratio = round(long_avg / short_avg, 2) if short_avg > 0 else 0.0

    bits = []
    for i in range(0, len(symbols) - 1, 2):
        pair = symbols[i : i + 2]
        if pair == "SL":
            bits.append("0")
        elif pair == "LS":
            bits.append("1")
        else:
            bits.append("?")
    bit_str = "".join(bits)[:32]
    clean_ratio = round(1.0 - (bit_str.count("?") / max(len(bit_str), 1)), 2)
    return {
        "count": len(pulses),
        "short_us": short_avg,
        "long_us": long_avg,
        "ratio": ratio,
        "bits": bit_str,
        "clean_ratio": clean_ratio,
    }


def fetch_tactical_brief(level: str, metrics: str, fallback: str) -> str:
    prompt = (
        "You are an onboard tactical AI scanner (Stark/SHIELD field HUD) analyzing 433.92 MHz RF hardware telemetry. "
        "Stay strictly grounded in the numbers—never invent unseen physical objects. "
        f"Alert Level: {level}. Telemetry: {metrics}. "
        "Give a crisp 1-to-2 sentence tactical readout explaining signal integrity. "
        "Return strict JSON with key 'brief'."
    )
    for model_name in MODELS_TO_TRY:
        for attempt in range(2):
            try:
                resp = client.models.generate_content(
                    model=model_name,
                    contents=prompt,
                    config=types.GenerateContentConfig(response_mime_type="application/json"),
                )
                return json.loads(resp.text).get("brief", fallback)
            except Exception as exc:
                if "503" in str(exc) or "UNAVAILABLE" in str(exc):
                    time.sleep(1.2 * (attempt + 1))
                    continue
                break
    return fallback


class SerialScannerWorker(QThread):
    telem_updated = pyqtSignal(int, float, float, float, int)  # edges, duty, base, thresh, vault_count
    alert_triggered = pyqtSignal(str, str, str, str)  # level_tag, codename, metrics, brief
    status_changed = pyqtSignal(str)

    def __init__(self) -> None:
        super().__init__()
        self._running = True

    def stop(self) -> None:
        self._running = False

    def run(self) -> None:
        vault = load_vault()
        edge_hist: deque[int] = deque(maxlen=40)
        last_frame: dict | None = None
        last_alert = 0.0

        while self._running:
            try:
                with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1) as ser:
                    self.status_changed.emit(f"LINKED // {SERIAL_PORT} @ {BAUD_RATE}")
                    time.sleep(2)
                    while self._running:
                        line = ser.readline().decode("utf-8", errors="ignore").strip()
                        if not line:
                            continue

                        if line.startswith("FRAME:"):
                            try:
                                pulses = [int(x) for x in line[6:].split(",") if x]
                                if len(pulses) >= 24:
                                    last_frame = decode_frame(pulses)
                            except ValueError:
                                pass
                            continue

                        if line.startswith("TELEM:"):
                            try:
                                parts = dict(item.split("=") for item in line[6:].split(","))
                                edges = int(parts["EDGES"])
                                duty = float(parts["DUTY"])
                                pkt = int(parts["PKT"])
                            except ValueError:
                                continue

                            base_e = statistics.mean(edge_hist) if len(edge_hist) >= 5 else float(edges)
                            sd_e = max(statistics.pstdev(edge_hist), 4.0) if len(edge_hist) >= 5 else 4.0
                            thresh = round(max(base_e + 3.0 * sd_e, 25.0), 1)
                            edge_hist.append(edges)

                            self.telem_updated.emit(edges, duty, round(base_e, 1), thresh, len(vault))

                            now = time.time()
                            has_structured = last_frame is not None and last_frame["clean_ratio"] >= 0.70

                            if (pkt != 0 or has_structured or edges >= thresh) and (now - last_alert) >= ALERT_COOLDOWN_SEC:
                                last_alert = now
                                if pkt != 0:
                                    sig_key = f"PKT_{pkt}"
                                    codename = vault.setdefault(sig_key, f"BEACON-{len(vault) + 1:02d}")
                                    save_vault(vault)
                                    level_tag = "LEVEL-4 // LOCKED BEACON"
                                    metrics = f"PKT={pkt} | EDGES={edges} | DUTY={duty:.1f}%"
                                    fallback = f"Locked verified 433.92 MHz digital beacon {codename} (ID {pkt})."
                                elif has_structured and last_frame is not None:
                                    sig_key = f"BITS_{last_frame['bits'][:16]}"
                                    codename = vault.setdefault(sig_key, f"SIG-{len(vault) + 1:02d}")
                                    save_vault(vault)
                                    level_tag = "LEVEL-3 // PULSE SIGNATURE"
                                    metrics = f"Pulses={last_frame['count']} | Ratio={last_frame['ratio']}x | Bits={last_frame['bits'][:20]}"
                                    fallback = f"Structured pulse frame ({last_frame['ratio']}x ratio) logged as {codename}."
                                else:
                                    codename = "EMI / FIELD SPIKE"
                                    level_tag = "LEVEL-2 // RF ANOMALY"
                                    metrics = f"EDGES={edges} (Thresh={thresh}) | DUTY={duty:.1f}%"
                                    fallback = f"Broadband RF/EMI spike hit {edges} edges at {duty:.1f}% duty cycle."

                                brief = fetch_tactical_brief(level_tag, metrics, fallback)
                                self.alert_triggered.emit(level_tag, codename, metrics, brief)
                                last_frame = None
            except Exception as exc:
                self.status_changed.emit(f"RETRYING {SERIAL_PORT}... ({exc})")
                time.sleep(2.5)


class ArcGaugeWidget(QWidget):
    """Custom Stark-style dual-arc gauge for live EDGES and DUTY%."""

    def __init__(self) -> None:
        super().__init__()
        self.setFixedSize(130, 130)
        self.edges = 0
        self.duty = 0.0
        self.thresh = 25.0
        self.alert_active = False

    def update_values(self, edges: int, duty: float, thresh: float, alert_active: bool) -> None:
        self.edges = edges
        self.duty = duty
        self.thresh = thresh
        self.alert_active = alert_active
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        outer_rect = QRectF(10, 10, 110, 110)
        inner_rect = QRectF(24, 24, 82, 82)

        # Background rings
        painter.setPen(QPen(QColor(0, 210, 255, 45), 6))
        painter.drawArc(outer_rect, 0, 360 * 16)
        painter.setPen(QPen(QColor(255, 175, 0, 45), 5))
        painter.drawArc(inner_rect, 0, 360 * 16)

        # Active EDGES arc (outer ring, cyan or red-amber on alert)
        edge_frac = min(self.edges / max(self.thresh * 1.5, 150.0), 1.0)
        edge_color = QColor(255, 75, 75, 235) if self.alert_active else QColor(0, 235, 255, 235)
        painter.setPen(QPen(edge_color, 6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(outer_rect, 90 * 16, int(-edge_frac * 360 * 16))

        # Active DUTY% arc (inner ring, amber)
        duty_frac = min(max(self.duty / 100.0, 0.0), 1.0)
        painter.setPen(QPen(QColor(255, 185, 30, 230), 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawArc(inner_rect, 90 * 16, int(-duty_frac * 360 * 16))

        # Center readout
        painter.setPen(QColor(225, 250, 255))
        painter.setFont(QFont("Consolas", 15, QFont.Weight.Bold))
        painter.drawText(outer_rect.adjusted(0, -10, 0, -10), Qt.AlignmentFlag.AlignCenter, f"{self.edges}")

        painter.setPen(QColor(0, 220, 255, 200))
        painter.setFont(QFont("Consolas", 8))
        painter.drawText(outer_rect.adjusted(0, 14, 0, 14), Qt.AlignmentFlag.AlignCenter, "EDGES")


class StarkTacticalHUD(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._drag_pos: QPoint | None = None
        self._last_alert_ts = 0.0
        self._init_ui()

        self.worker = SerialScannerWorker()
        self.worker.telem_updated.connect(self.on_telem)
        self.worker.alert_triggered.connect(self.on_alert)
        self.worker.status_changed.connect(self.on_status)
        self.worker.start()

    def _init_ui(self) -> None:
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(410, 310)

        # Position top-right with 24px margin
        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.width() - self.width() - 24, 24)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        self.panel = QFrame()
        self.panel.setObjectName("HudPanel")
        self.panel.setStyleSheet(
            """
            QFrame#HudPanel {
                background-color: rgba(8, 18, 28, 205);
                border: 1.5px solid rgba(0, 225, 255, 175);
                border-radius: 12px;
            }
            QLabel {
                color: #D9F7FF;
                font-family: 'Consolas', 'Cascadia Code', monospace;
            }
            QPushButton {
                background-color: rgba(255, 65, 65, 55);
                color: #FF8A8A;
                border: 1px solid rgba(255, 95, 95, 140);
                border-radius: 5px;
                font-family: 'Consolas', monospace;
                font-weight: bold;
                padding: 2px 8px;
            }
            QPushButton:hover {
                background-color: rgba(255, 65, 65, 130);
                color: #FFFFFF;
            }
            """
        )
        root.addWidget(self.panel)

        layout = QVBoxLayout(self.panel)
        layout.setContentsMargins(14, 10, 14, 12)
        layout.setSpacing(8)

        # Header bar
        header = QHBoxLayout()
        title = QLabel("STARK // 433.92 MHz TACTICAL HUD")
        title.setStyleSheet("color: #00E5FF; font-weight: bold; font-size: 12px; letter-spacing: 1px;")
        close_btn = QPushButton("X")
        close_btn.setFixedSize(24, 22)
        close_btn.clicked.connect(self.close)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(close_btn)
        layout.addLayout(header)

        # Sub-status line
        self.status_lbl = QLabel(f"INITIALIZING {SERIAL_PORT}...")
        self.status_lbl.setStyleSheet("color: #7CC8D8; font-size: 10px;")
        layout.addWidget(self.status_lbl)

        # Middle telemetry row: Arc Gauge + Metrics
        mid_row = QHBoxLayout()
        self.gauge = ArcGaugeWidget()
        mid_row.addWidget(self.gauge)

        stats_col = QVBoxLayout()
        stats_col.setSpacing(4)
        self.duty_lbl = QLabel("DUTY CYCLE : 00.0 %")
        self.duty_lbl.setStyleSheet("color: #FFB82E; font-size: 12px; font-weight: bold;")
        self.base_lbl = QLabel("ROOM BASE  : 00.0 EDGES")
        self.base_lbl.setStyleSheet("font-size: 11px;")
        self.thresh_lbl = QLabel("LOCK THRESH: 25.0 EDGES")
        self.thresh_lbl.setStyleSheet("font-size: 11px;")
        self.vault_lbl = QLabel(f"VAULT SIGS : {len(load_vault())} LOCKED")
        self.vault_lbl.setStyleSheet("color: #55FFB8; font-size: 11px; font-weight: bold;")

        stats_col.addWidget(self.duty_lbl)
        stats_col.addWidget(self.base_lbl)
        stats_col.addWidget(self.thresh_lbl)
        stats_col.addWidget(self.vault_lbl)
        mid_row.addLayout(stats_col)
        layout.addLayout(mid_row)

        # Beacon Lock & Tactical Briefing Box
        self.lock_box = QFrame()
        self.lock_box.setStyleSheet(
            """
            QFrame {
                background-color: rgba(0, 35, 52, 165);
                border: 1px solid rgba(0, 225, 255, 100);
                border-radius: 8px;
            }
            """
        )
        lock_layout = QVBoxLayout(self.lock_box)
        lock_layout.setContentsMargins(10, 8, 10, 8)
        lock_layout.setSpacing(3)

        self.beacon_title = QLabel("STATUS // AMBIENT SWEEP ACTIVE")
        self.beacon_title.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: bold;")
        self.beacon_metrics = QLabel("Awaiting structured pulse frame or PKT ID...")
        self.beacon_metrics.setStyleSheet("color: #9ED8E6; font-size: 10px;")
        self.beacon_brief = QLabel("Bring a 433 MHz transmitter within range or monitor EMI drift.")
        self.beacon_brief.setWordWrap(True)
        self.beacon_brief.setStyleSheet("color: #E5FAFF; font-size: 10px;")

        lock_layout.addWidget(self.beacon_title)
        lock_layout.addWidget(self.beacon_metrics)
        lock_layout.addWidget(self.beacon_brief)
        layout.addWidget(self.lock_box)

    def on_status(self, text: str) -> None:
        self.status_lbl.setText(text)

    def on_telem(self, edges: int, duty: float, base: float, thresh: float, vault_count: int) -> None:
        alert_active = (time.time() - self._last_alert_ts) < 2.5
        self.gauge.update_values(edges, duty, thresh, alert_active)
        self.duty_lbl.setText(f"DUTY CYCLE : {duty:04.1f} %")
        self.base_lbl.setText(f"ROOM BASE  : {base:04.1f} EDGES")
        self.thresh_lbl.setText(f"LOCK THRESH: {thresh:04.1f} EDGES")
        self.vault_lbl.setText(f"VAULT SIGS : {vault_count} LOCKED")

    def on_alert(self, level_tag: str, codename: str, metrics: str, brief: str) -> None:
        self._last_alert_ts = time.time()
        ts = time.strftime("%H:%M:%S")
        is_beacon = "LEVEL-4" in level_tag or "LEVEL-3" in level_tag
        accent = "#55FFB8" if is_beacon else "#FF6B6B"

        self.beacon_title.setStyleSheet(f"color: {accent}; font-size: 11px; font-weight: bold;")
        self.beacon_title.setText(f"[{ts}] {level_tag} -> {codename}")
        self.beacon_metrics.setText(metrics)
        self.beacon_brief.setText(brief)

    # Allow dragging the frameless HUD anywhere on screen
    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event) -> None:
        if self._drag_pos is not None and event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, event) -> None:
        self._drag_pos = None

    def closeEvent(self, event) -> None:
        self.worker.stop()
        self.worker.wait(1500)
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    hud = StarkTacticalHUD()
    hud.show()
    sys.exit(app.exec())